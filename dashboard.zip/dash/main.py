import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

# Configuração da página
st.set_page_config(page_title="Dashboard de Saúde Mental", layout="wide")

# Carregar dados
@st.cache_data
def load_data():
    csv_path = Path(__file__).resolve().parent / "student_mental_health_burnout.csv"
    return pd.read_csv(csv_path)

df = load_data()

st.title("Dashboard de Saúde Mental e Burnout em Estudantes")
st.write("Dataset:Student Mental Health and Burnout(Kaggle)" \
"Justificativa:O burnout entre estudantes é um problema crescente, principalmente no ensino superior.O dataset contém variáveis relevantes como gênero, curso, qualidade do sono, nível de estresse e nível de burnout (baixo, médio, alto).Permite investigar relações entre hábitos de vida (sono, estresse) e o desgaste emocional, gerando insights para intervenções institucionais.Dados com boa variedade categórica e numérica, ideais para visualizações interativas.")
st.markdown("Fonte: Kaggle")

st.sidebar.header("Filtros")
selected_gender = st.sidebar.multiselect("Gênero", df['gender'].unique(), default=df['gender'].unique())
selected_course = st.sidebar.multiselect("Curso", df['course'].unique(), default=df['course'].unique())
selected_burnout = st.sidebar.multiselect("Nível de Burnout", df['burnout_level'].unique(), default=df['burnout_level'].unique())

df_filtered = df[
    (df['gender'].isin(selected_gender)) &
    (df['course'].isin(selected_course)) &
    (df['burnout_level'].isin(selected_burnout))
]

#Dividir a tela em duas colunas para os gráficos
col1, col2 = st.columns(2)

#Gráfico de distribuição dos níveis de burnout
with col1:
    graf_pizza = px.pie(df_filtered, names='burnout_level', title='Distribuição dos Níveis de Burnout')
    st.plotly_chart(graf_pizza, use_container_width=True)

#Gráfico de burnout por gênero
with col2:
    graf_bar = px.histogram(df_filtered, x='gender', color='burnout_level',
                           title='Burnout por Gênero (%)', barmode='group', histnorm='percent')
    st.plotly_chart(graf_bar, use_container_width=True)

#Gráfico de burnout por curso
graf_course = px.histogram(df_filtered, x='course', color='burnout_level',
                          title='Burnout por Curso (%)', barmode='group', histnorm='percent')
st.plotly_chart(graf_course, use_container_width=True)

#Gráficos de qualidade do sono e nível de estresse por burnout
graf_sleep = px.histogram(df_filtered, x='sleep_quality', color='burnout_level',
                             title='Qualidade do Sono vs Burnout', barmode='group')
st.plotly_chart(graf_sleep, use_container_width=True)

#Gráfico de nível de estresse por burnout
graf_stress = px.histogram(df_filtered, x='stress_level', color='burnout_level',
                              title='Nível de Estresse vs Burnout', barmode='group')
st.plotly_chart(graf_stress, use_container_width=True)
